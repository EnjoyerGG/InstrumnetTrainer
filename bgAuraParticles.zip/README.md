# InstrumnetTrainer
A website use for recognize the rhythme and figure out the correct bits, and show it on time.

And now it is in beta version, call for great amount of data set to train it.

---7.27---
Rebuild the structure and the frame of the whole project